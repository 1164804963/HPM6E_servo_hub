Win10 or later
- x64
- x86

Former Windows versions
- x86_legacy